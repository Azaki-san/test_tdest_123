from datetime import datetime

import zmq
import json
import sys

WEATHER_INPUT_PORT = 5555
IP_ADD = '127.0.0.1'


def main():
    context = zmq.Context()
    co2_socket = context.socket(zmq.SUB)
    co2_socket.connect(f"tcp://{IP_ADD}:{WEATHER_INPUT_PORT}")
    co2_socket.setsockopt_string(zmq.SUBSCRIBE, "co2")

    try:
        while True:
            message = co2_socket.recv_string()
            print(f"Received weather data: {message}")
            _, data = message.split(" ", 1)
            data = json.loads(data)
            with open("co2_data.log", "a") as f:
                f.write(f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} - {message}\n")
            if data["co2"] > 400:
                print("Danger Zone! Please do not leave home")
    except KeyboardInterrupt:
        print("Terminating data_processor")
        co2_socket.close()
        context.term()


if __name__ == "__main__":
    main()
