import zmq
import json
import threading
from datetime import datetime, timedelta

WEATHER_INPUT_PORT = 5555
FASHION_SOCKET_PORT = 5556

IP_ADD = '127.0.0.1'

latest_data = {"average-temperature": 0.0, "temperatures-humidity's": [],
               "average-hum": 0.0}

mutex = threading.Lock()


def average_temperature_humidity(data=None):
    global latest_data
    with mutex:
        x = 0
        if data is not None:
            latest_data["temperatures-humidity's"].append(data)
        timestamp = datetime.now()
        if latest_data["temperatures-humidity's"]:
            while (timestamp - datetime.strptime(latest_data["temperatures-humidity's"][x]["time"],
                                                 "%Y-%m-%d %H:%M:%S")) > timedelta(seconds=30):
                latest_data["temperatures-humidity's"].pop(x)

            latest_data["average-hum"] = sum([x["humidity"] for x in latest_data["temperatures-humidity's"]]) / len(
                latest_data["temperatures-humidity's"])

            latest_data["average-temperature"] = sum(
                [x["temperature"] for x in latest_data["temperatures-humidity's"]]) / len(
                latest_data["temperatures-humidity's"])


def recommendation():
    result = ""
    average_temperature_humidity()
    if latest_data['average-temperature'] < 10:
        result = "Today weather is cold. Its better to wear warm clothes"
    elif 10 < latest_data['average-temperature'] < 25:
        result = "Feel free to wear spring/autumn clothes"
    else:
        result = "Go for light clothes"
    print(result)
    return result


def report():
    average_temperature_humidity()
    result = f"The last 30 sec average Temperature is {round(latest_data['average-temperature'], 2)} and Humidity {round(latest_data['average-hum'], 2)}"
    print(result)
    return result


def client_handler(socket, context):
    try:
        while True:
            message = socket.recv_string()
            if message == "Fashion":
                socket.send_string(recommendation())
            elif message == "Weather":
                socket.send_string(report())
    except KeyboardInterrupt:
        socket.close()
        context.term()


def weather_data_receiver():
    context = zmq.Context()
    weather_socket = context.socket(zmq.SUB)
    weather_socket.connect(f"tcp://{IP_ADD}:{WEATHER_INPUT_PORT}")
    weather_socket.setsockopt_string(zmq.SUBSCRIBE, "weather")
    try:
        while True:
            message = weather_socket.recv_string()
            print(f"Received weather data: {message}")
            _, data = message.split(' ', 1)
            data = json.loads(data)
            average_temperature_humidity(data)
            with open("weather_data.log", "a") as f:
                f.write(f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} - {message}\n")
    except KeyboardInterrupt:
        weather_socket.close()
        context.term()


def main():
    context = zmq.Context()
    fashion_socket = context.socket(zmq.REP)
    fashion_socket.bind(f"tcp://{IP_ADD}:{FASHION_SOCKET_PORT}")

    client_thread = threading.Thread(target=client_handler, args=(fashion_socket, context))
    client_thread.daemon = True
    weather_thread = threading.Thread(target=weather_data_receiver)
    weather_thread.daemon = True
    client_thread.start()
    weather_thread.start()
    try:
        client_thread.join()
        weather_thread.join()
    except KeyboardInterrupt:
        print("Terminating data_processor")
        exit(0)


if __name__ == "__main__":
    main()
