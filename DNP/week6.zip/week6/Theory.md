# English Class

- **Consistency:** maintaining the same behavior or state in different scenarios/places
- **Replication:** duplicating stuff across multiple places
- **Coordination:** organized communication to achieve a common goal
- **Synchronization:** making sure all entities are on the same page (typically the time).
- **Consensus:** entities are done fighting and finally agreed on a common truth.
- **Election:** selecting a representer or a special entity.
- **Fault Tolerance:** hiding broken internals, trying to maintain functionality.
